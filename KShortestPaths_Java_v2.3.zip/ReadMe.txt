The package contains the implementation of Yen's algorithm for top-k shortest paths in a directed weighted graph. 

Note that:
1. It's implemented in Java. (The version is 2.3)
2. In order to compile the source code, JRE version in your machine must be 1.5+. 
3. The way to use the package is shown in the testing case (edu.asu.emit.qyan.test.*).